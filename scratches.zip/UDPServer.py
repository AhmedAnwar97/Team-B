#
# from socket import *
# import numpy as np
# import cv2
#
# host = "127.0.0.1"
# port = 4096
# buf = 1024
# addr = (host, port)
# fName = 'img.jpg'
# timeOut = 0.05
#
# def foo():
#     while True:
#         s = socket(AF_INET, SOCK_DGRAM)
#         s.bind(addr)
#         data, address = s.recvfrom(buf)
#         f = open(data, 'wb')
#         print('type of address is ',type(address))
#         print('type of data is ',type(data))
#         data, address = s.recvfrom(buf)
#
#         try:
#             while(data):
#                 f.write(data)
#                 print('aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa')
#                 s.settimeout(timeOut)
#                 data, address = s.recvfrom(buf)
#         except timeout:
#             f.close()
#             s.close()
#         image = cv2.imread(fName)
#         cv2.imshow('recv', image)
#         if cv2.waitKey(1) & 0xFF == ord('q'):
#             break
#
# if __name__ == '__main__':
#     foo()
# cv2.destroyAllWindows()


import cv2
import  socket
import numpy as py

host='127.0.0.1'
port=12000

s=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
s.bind((host,port))
imShape=''
while True:
    data,addr=s.recvfrom(11520)
    if imShape=='':
        imShape=data
    else :
        imShape+=data


    if len(imShape)==80*11520:
        imShape=py.frombuffer(imShape,dtype=py.uint8)
        print(py.shape(imShape))
        img=imShape.reshape(480,640,3)

        cv2.imshow('transmitted',img)
        imShape=''
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break
cv2.destroyAllWindows()

# import socket
# import numpy
# import time
# import cv2
#
# UDP_IP="127.0.0.1"
# UDP_PORT = 8888
# sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
# sock.bind((UDP_IP, UDP_PORT))
#
# s=""
# x=0
# while True:
#       data, addr = sock.recvfrom(46080)
#       if s=="":
#           s=data
#           x+=1
#           print(x)
#       else:
#           s+= data
#       if len(s) == (46080*20):
#           frame = numpy.fromstring (s, dtype=numpy.uint8)
#           frame = frame.reshape(480,640,3)
#           cv2.imshow("transmitted",frame)
#           x=0
#           s=""
#       if cv2.waitKey(1) & 0xFF == ord('q'):
#           break
