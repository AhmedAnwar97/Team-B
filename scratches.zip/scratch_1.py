import cv2

camera= cv2.videoCapture(0)

while true
    _,frame=camera.read()
#returns frame and a bool , the bool tells if camera is ion or not , if we have a frame or not
    cv2.imshow('frames',frame)
    if cv2.waitKey(1)==27: #27 is the esc keyboard key ,if presses , image gets no longer shown
        break;
#image =cv2.imread('myimagewithpass.jpg',0)

rows ,cols =image.shape