#we communicate b/n ports , so i can relate unt2 and client even if they have different languages
import  socket

host='127.0.0.1'
port=8081
s=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
s.connect((host,port))
msg = s.recv(1024)
msg2= s.recv(1024)
# max bytes to be received is 1024 , will ignore anymore bytes - this is a buffer-

print(msg.decode())
print(msg2.decode())
while True:
    msg_to_send=input()
    s.send(str.encode(msg_to_send))
    if msg_to_send == 'close':
        conn.close()
        break


#try and except or try and catch to handle exceptions

'''
while True
    try:
        s.connect((host, port))
        connect is a function that connects client to socket of server
        if there's no socket for the port , there happens an exception and am handling it here
        break
    except:
        pass

replace the while true here by signal and slots to catch of there is an exception , perform this
instead of keeping looping here just waiting and checking

deliverables:
-python server program
-Qt client program  (gets open twice to have two windows)
'''