'''

THIS ALL IS TCP COMMUNICATION
NOTE THAT SERVER IS A BRIDGE USED ODRIGINALLY TO HELP TWO CLIENTS COMMUNICATE WITH EACH OTHER
ip is identifier on a network (your ip is different according to newtwork

ip has ports tree , every port has an address so that you can address it specifically

ports are defined by defualt , by the OS, while a socket is user defined
a port is a virtual device , like the mouse .

if a socket get a port , no othe socket can use this port

'''



import  socket
from  _thread import*

# the * means import everything
#or i can replace it with my desired fun only

def handleClient(conn,addr):
    conn.send(str.encode('Welcome to the server'))
    conn.send(str.encode("Are you new here ?"))
    while True:
        msg= conn.recv(1024).decode()
        if not msg:
            print('lost connection with client', addr)
            conn.close()
            break
        else:
# send() is a function whosoe parameter isn't a string , it's  an array of bits (0s and 1s)
            print('client %s says' % str(addr), msg)


host='127.0.0.1'
port=8081
#this port is still just a number , but i will assign it next
# to creat socket
sock=s=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
#s=sock=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
s.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1)
# TCB IS A PROTOCOL THAT SENDS DATA AND SEND AN ACKNOWLEDGEMENT TO SENDER TO CONFIRM RECIEPTION
#UNLIKE BCB

s.bind((host,port))
s.listen(5)
#means i can welcome only 5 connections , more than that will be queued and wait
print('listening for incoming connections')
while True :
    conn,addr=s.accept() #it's like an input ,will freeze here till it get an applicant
#addr is the indentifier of the port that connects
#conn is an object that represents the client
#s.accept()will return somthing in the form ('0.0.0.0',51231516) which is host (object) and  ip(id)
    print ('client',addr,'has been connected')
    start_new_thread(handleClient,(conn,addr,))




#to solve the error , change port to get an empty port , not a used one