print ("Hello world")

'''This
is
a comment
'''
#this is also a single line comment
'''
power is carried out by using double astyeric **

// is floor divison (eliminates decimal nubmer)
'''
'''
z=9/2
print(z)
print (type(z))
z=str(z)
print ("your number is",z)
print (type(z))
print('hello') #default end is '\n' , change it if you want
print ('world')
print ('hi',end="")
print ('World')
s='So hey now brown cow'
print (s[:5])
print (s[-2:])
'''
#list are equav arrays of python
x=[1,5,'a']
print (type(x))
print(len(x))
print (x)
x.append('r')
print (x)
x.insert(2,'s')
print (x)
x.remove('r')
print (x)
x.append(1)
x.append(19)
x.append(3)
print (x)
#a tuple is list that can't be edited
tupele1=(0,1,2,3)
print (tupele1)
# a dictionary has no index for its elements , instead , you give its elements and index in the dictionary and call these
#elements using this index given by you , example :
d={'two' : 2 , 'three':3}
print(type(d))
#print(d(2))
#syntax of conditions:

x=5
'''
if x>2 :
    print(3);
else:
    print (11)
'''
if x==3:
    print(3)
elif x==5:
    print(5)
elif x==6:
    print ('null')

# is is equavelant to == , but not all the time , you may , and will, find some differences

x=[1,2,3]
y=list(x)

if x==y:
    print ('true')
else:
    print ('false')
if x is y:
    print ('true')
else:
    print ('false')
# is compares if they both have the same address
#loops

for i in [0,3,4]:
    print(i,end=" ")
print('\n')
for i in range (0,9):
    print(i,end=' ')
print('\n')
x=6
while x>=0:
    print (x,end=' ')
    x-=1
print('\n')

# if x=11 and y=11 , python gives x and y same address to save memory (probably)
#functions definiton

def sum(x,y):
    x+=y
    return x
print(sum(3,4))
#functions can return more than a variable

def fun(x,y,z):
    return  x,y,z

# if i create a variable eqyal to that function , it is created as a tuple

z= fun(3,7,12)
print (z)
print (type(z))
a,b,c=fun(1,2,3)
print (a)
print (type(a))

#classes :

class myFirst:
    name
    age
    height
    lastName
    foods
    # any function inside a class must have a first parameter 'self'
    # to have  a private varualbe , use '__' before its name
    def myFirst(self):
            



s,age1=myFirst(x)
