#ifndef TCPSOCKET_H
#define TCPSOCKET_H

//#include

class tcpsocket
{
public:
    tcpsocket();
};

#endif // TCPSOCKET_H
