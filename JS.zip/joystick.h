#ifndef JOYSTICK_H
#define JOYSTICK_H
#include <SDL.h>
#include <SDL_joystick.h>
#include <QTimer>
#include <QDebug>

class joystick : public QObject
{
    Q_OBJECT
public:
    joystick();
    float getMapped();
    void ProcImgSend();

public slots:
    void JSLoop();
    void print();
private:
    SDL_Joystick * js;
    SDL_Event * event;
    int minX=32000,maxX=0,minY=32000,maxY=0,minZ=32000,maxZ=0,maxR=0,minR=32000;
    int map(int value);
    QTimer * timerJS;
};

#endif // JOYSTICK_H
