#include "tcpsocket.h"

tcpsocket::tcpsocket()
{

}
