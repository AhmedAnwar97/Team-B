#include "udpsocket.h"

udpsocket::udpsocket()
{

}
