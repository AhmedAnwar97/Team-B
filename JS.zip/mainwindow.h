#ifndef MAINWINDOW_H
#define MAINWINDOW_H
#include <QMainWindow>
#include "joystick.h"
#include <QPushButton>
namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
private:
    Ui::MainWindow *ui;
    joystick * controller;
    QPushButton * bttnPrint;
};

#endif // MAINWINDOW_H
