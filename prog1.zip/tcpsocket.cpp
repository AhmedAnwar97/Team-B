#include "tcpsocket.h"

tcpsocket::tcpsocket(QObject *parent, quint16 port)
{
    sock=new QTcpSocket(parent);
    sock->connectToHost("127.0.0.1",port);

    connect(sock,SIGNAL(connected()),this,SLOT(connected()));
//    connect(sock,SIGNAL(()),this,SLOT(connected()));
    connect(sock,SIGNAL(disconnected()),this,SLOT(disconnected()));
    connect(sock,SIGNAL(readyRead()),this,SLOT(readyRread()));
//    connect(sock,SIGNAL(bytesWritten(qint64))),this,SLOT(bytesWritten(qint64));
    if (sock->waitForConnected(5000))
        qDebug()<<"Error : "<<sock->error();
    message=NULL;
}

void tcpsocket::sendOrder()
{
    sock->write(message);
    sock->waitForBytesWritten(10);
}


void tcpsocket::setMessage(QString msg)
{
//    int elements=msg.size()
    qDebug()<<msg.size();
}


void tcpsocket::connected(){

    qDebug()<<"connection detected";
    sock->write("Ready to send data");
    sock->waitForBytesWritten(200);
}


void tcpsocket::disconnected(){
//    QHostAddress sender;
//    qDebug()<<"Client"<<sender.toString();

}


void tcpsocket::bytesWritten(qint64 bytes){
    qDebug()<<bytes;

}


void tcpsocket::readyRread(){


}


void tcpsocket::newConnection(){



}
