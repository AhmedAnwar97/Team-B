#include "joystick.h"

joystick::joystick()
{


    timerJS=new QTimer(this);
    timerJS->setInterval(50);
    timerJS->start();
//    bttnPrint=new QPushButton(this);
//    bttnPrint->setText("Print Variables");
    connect(timerJS,SIGNAL(timeout()),this,SLOT(JSLoop()));
//    connect(bttnPrint,SIGNAL(clicked(bool)),this,SLOT(print()));


    SDL_Init(SDL_INIT_JOYSTICK);
    if (SDL_INIT_JOYSTICK<0){
        qDebug()<<"failed to intialize";}
    js=SDL_JoystickOpen(0);
    SDL_JoystickEventState(SDL_ENABLE);
    event = new SDL_Event;
}



float joystick::getMapped()
{


}

void joystick::ProcImgSend()
{
    qDebug()<<"Image shall be sent from her for processing";
}

void joystick::JSLoop()
{

    while (SDL_PollEvent(event)){
        switch(event->type){
            case SDL_JOYAXISMOTION:
                if (event->jaxis.axis==0){
                    x=map(event->jaxis.value);
                    qDebug()<<"X is "<<x;
                    if (map(event->jaxis.value)>maxX){
                        maxX=map(event->jaxis.value);
                    }
                    if(map(event->jaxis.value)<minX){
                        minX=map(event->jaxis.value);
                    }
                }
                if (event->jaxis.axis==1){
                    y=map(event->jaxis.value);
                    qDebug()<<"Y is "<<y;
                    if (map(event->jaxis.value)>maxY){
                        maxY=map(event->jaxis.value);
                    }
                    if(map(event->jaxis.value)<minY){
                        minY=map(event->jaxis.value);
                    }
                }

                if (event->jaxis.axis==2){
                    z=map(event->jaxis.value);
                    qDebug()<<"Z is "<<z;
                    if (map(event->jaxis.value)>maxZ){
                        maxZ=map(event->jaxis.value);
                    }
                    if(map(event->jaxis.value)<minZ){
                        minZ=map(event->jaxis.value);
                    }
                }
                if (event->jaxis.axis==3){
                    r=map(event->jaxis.value);
                    qDebug()<<"R is "<<r;
                    if (map(event->jaxis.value)>maxR){
                        maxR=map(event->jaxis.value);
                    }
                    if(map(event->jaxis.value)<minR){
                        minR=map(event->jaxis.value);
                    }
                break;
//            case SDL_JoyBallEvent:

//                break;
            case SDL_JOYBUTTONDOWN:
                qDebug()<<event->jbutton.button;
                if (event->jbutton.button==0){
                    ProcImgSend();
                    print();
                }
//                else if (event->jbutton.button==1){
//                    print();
//                }
                else if (event->jbutton.button==2){
                    pist1Strike();
                }
                else if (event->jbutton.button==3){
                    pist2Strike();
                }
                break;

            case SDL_JOYBUTTONUP:
                if (event->jbutton.button==2){

                    pist1Return();
                }
                else if (event->jbutton.button==3){

                    pist2Return();
                }
                break;

//            case SDL_JOYHATMOTION:


//                break;
            case SDL_JOYDEVICEREMOVED:
                SDL_JoystickClose(js);
                qDebug()<<"JS removed";
                break;
            case SDL_JOYDEVICEADDED:
                    qDebug()<<"JS added";
                    SDL_Init(SDL_INIT_JOYSTICK);
                    js=SDL_JoystickOpen(0);
                    break;

        }
    }

}
}

void joystick::print()
{
    qDebug()<<"max X is"<<maxX;
    qDebug()<<"max Y is"<<maxY;
    qDebug()<<"max Z is"<<maxZ;
    qDebug()<<"max R is"<<maxR;
    qDebug()<<"min X is"<<minX;
    qDebug()<<"min Y is"<<minY;
    qDebug()<<"min Z is"<<minZ;
    qDebug()<<"min R is"<<minR;

}


int joystick::map(int value)
{
    if (abs(value) <1200){
        return 0;
    }
    else{
        value=round(value*(100-0)/(32768-1200));
        if (value>100)
            value=100;
        else if (value<-100)
            value =-100;

        return value;
    }
}


void joystick::pist1Strike(){

        qDebug()<<"Piston 1 shall strike now";
}


void joystick::pist2Strike(){

    qDebug()<<"Piston 2 shall strike now";

}


void joystick::pist1Return(){

    qDebug()<<"Piston 1 shall return now";

}


void joystick::pist2Return(){


    qDebug()<<"Piston 2 shall return now";
}
