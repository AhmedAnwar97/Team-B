#ifndef TCPSOCKET_H
#define TCPSOCKET_H
#include <string.h>
#include <QTcpSocket>
#include <QDebug>
class tcpsocket : public QObject
{
    Q_OBJECT
public:
    tcpsocket(QObject * parent=0,quint16 port=12000);

    void setMessage (QString msg);
public slots:
    void connected();
    void disconnected();
    void bytesWritten(qint64 bytes);
    void readyRread();
    void newConnection();
    void sendOrder();
private:
    QTcpSocket * sock;
    char* message;
};

#endif // TCPSOCKET_H
