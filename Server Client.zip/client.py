import socket

 # c lient el hy connect 3l server,   ports defined by default lakn socket ana ba3mlo create yshtghl w2t zy program byt3aml m3 el port da ta7deedan
host = '127.0.0.1'  # yfhm eno local host
port = 8082
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
while True:
    try:
        s.connect((host, port))
        break
    except:
        pass
msg = s.recv(1024)  # hareceive 1024 byte bs
print(msg.decode())
 
while True:
    
    print('type msg to send')
    msg_to_send = input()
    s.send(str.encode(msg_to_send))
    if msg_to_send == 'close':
        break


    
