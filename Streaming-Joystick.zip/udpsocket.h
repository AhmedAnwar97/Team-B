#ifndef UDPSOCKET_H
#define UDPSOCKET_H


class udpsocket
{
public:
    udpsocket();
};

#endif // UDPSOCKET_H
