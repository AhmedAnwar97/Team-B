#include "gstream.h"

gstream::gstream(QWidget *parent)
{
    verLay=new QVBoxLayout ();
    window=parent;
    window->setLayout(verLay);
//    window=new QWidget();
    action(parent);
}


int gstream::action(QWidget * renderingWindow)
{

    if (!g_thread_supported ())
      g_thread_init (NULL);

    gst_init (0, 0);
    int x=0;
    char * y= NULL;
    QApplication app(x, &y);
    app.connect(&app, SIGNAL(lastWindowClosed()), &app, SLOT(quit ()));

    // prepare the pipeline

    pipeline = gst_pipeline_new ("xvoverlay");
    pipeline = gst_parse_launch ("udpsrc port=5022 ! application/x-rtp,encoding-name=H264 ! rtpjitterbuffer ! rtph264depay ! avdec_h264 ! videoconvert ! ximagesink name=sink", NULL);
//    pipeline = gst_parse_launch ("udpsrc port=5000 ! application/x-rtp,encoding-name=H264 ! rtpjitterbuffer ! rtph264depay ! avdec_h264 ! videoconvert ! ximagesink name=sink", NULL);
//    pipeline = gst_parse_launch ("v4l2src device='/dev/video0' ! video/x-raw,width=320,height=240 ! videoconvert ! x264enc tune=zerolatency ! rtph264pay ! udpsink host='bta3 el computer' port=5022"
//                                 ,NULL);
    // prepare the ui
//    window->resize(800 , 600);
//    window->show();
    WId xwinid = window->winId();
    sink=gst_bin_get_by_name(GST_BIN(pipeline),"sink");
    gst_video_overlay_set_window_handle (GST_VIDEO_OVERLAY (sink), xwinid);

    /**********************************************************************************************/
//    renderingWindow->resize(800 , 600);
//    renderingWindow->show();
//    WId xwinid = renderingWindow->winId();
//    sink=gst_bin_get_by_name(GST_BIN(pipeline),"sink");
//    gst_video_overlay_set_window_handle (GST_VIDEO_OVERLAY (sink), xwinid);

    /**********************************************************************************************/
    // run the pipeline

    GstStateChangeReturn sret = gst_element_set_state (pipeline,
        GST_STATE_PLAYING);
    if (sret == GST_STATE_CHANGE_FAILURE) {
      gst_element_set_state (pipeline, GST_STATE_NULL);
      gst_object_unref (pipeline);
      // Exit application
      QTimer::singleShot(0, QApplication::activeWindow(), SLOT(quit()));
    }

    int ret = app.exec();

    window->hide();
    gst_element_set_state (pipeline, GST_STATE_NULL);
    gst_object_unref (pipeline);

    return ret;

}

QWidget *gstream::getStream()
{
    return window;
}

void gstream::setRenderingWindow(QWidget *window)
{

}
