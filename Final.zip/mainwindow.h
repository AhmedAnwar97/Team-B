#ifndef MAINWINDOW_H
#define MAINWINDOW_H
#include <QKeyEvent>
#include <QEvent>
#include <QMainWindow>
#include "food.h"
#include "snake.h"
#include <QGraphicsScene>
#include <QGraphicsView>
#include <QKeyEvent>
#include <QTimer>
#include <QGraphicsItem>
#include <QList>
#include <typeinfo>
#include <QString>
//#include <joystick.h>
#include <SDL.h>
#include <SDL_joystick.h>
namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
    void keyPressEvent(QKeyEvent *event);
    void moveByServer(QString order);
    void socketInit();
public slots:
    void moveByJoystick();
    void moverFn();
private:
    Ui::MainWindow *ui;
    QGraphicsScene * scene;
    QGraphicsView * screen;
    snake * ourCobra;
  //  snake * hunter;
    food * itsFood;
    int destination=0;
  //  int desti2=0;
    SDL_Joystick * js;
    SDL_Event event;

};

#endif // MAINWINDOW_H
