#include "snake.h"

snake::snake()
{
    QGraphicsRectItem *snakeBody=new QGraphicsRectItem(this);
    snakeBody->setRect(0,0,40,40);
    QBrush bru;
    bru.setColor(Qt::red);
    bru.setStyle(Qt::SolidPattern);
    snakeBody->setBrush(bru);
    snakeBodies.append(snakeBody);
    hori.setX(40);
    hori.setY(0);
    vert.setX(0);
    vert.setY(40);
    head=snakeBodies[0];
    tail=snakeBodies[0];
}

snake::~snake(){
    delete head;
    delete tail;
    delete tempo;
    for(int i=snakeBodies.size()-1;i>=0;i--){
        delete snakeBodies[i];
    }
    delete &snakeBodies;

};


void snake::move(int destination){
    //qDebug()<<snakeBodies.indexOf(tail);
    tempo=tail;
    if (destination==0){


        tail->setPos(head->pos()+hori);
        if (snakeBodies.indexOf(tail)==0)
            tail=snakeBodies[snakeBodies.size()-1];
        else
            tail=snakeBodies[snakeBodies.indexOf(tail)-1];
        head=tempo;
        if(head->x()+head->boundingRect().width()>1000){
            head->moveBy(-1000+head->boundingRect().height(),0);
        }
    }
    else if (destination==180){

        if(head->x()<0){
           head->moveBy(1000,0);
        }

        tail->setPos(head->pos()-hori);
       if (snakeBodies.indexOf(tail)==0)
           tail=snakeBodies[snakeBodies.size()-1];
       else
           tail=snakeBodies[snakeBodies.indexOf(tail)-1];
       head=tempo;

    }
    else if(destination==270){


        tail->setPos(head->pos()+vert);
       if (snakeBodies.indexOf(tail)==0)
           tail=snakeBodies[snakeBodies.size()-1];
       else
           tail=snakeBodies[snakeBodies.indexOf(tail)-1];
       head=tempo;
       if(head->y()>800){
          head->moveBy(0,-800);
       }
    }
    else if (destination==90){
        tail->setPos(head->pos()-vert);
        if (snakeBodies.indexOf(tail)==0)
            tail=snakeBodies[snakeBodies.size()-1];
        else
            tail=snakeBodies[snakeBodies.indexOf(tail)-1];
        head=tempo;
        if(head->y()<0){
            head->moveBy(0,800);
        }
    }
};

void snake::elongate(){

    QBrush bru;
    bru.setColor(Qt::yellow);
    bru.setStyle(Qt::SolidPattern);
    QGraphicsRectItem * body;
    body=new QGraphicsRectItem(this);
    body->setRect(0,0,40,40);
    body->setBrush(bru);
    snakeBodies.insert(snakeBodies.indexOf(tail),body);
//    qDebug()<<"added dot has the index "<<snakeBodies.indexOf(body);
//    qDebug()<<"tail has the index "<<snakeBodies.indexOf(tail);
};

QGraphicsRectItem * snake::getSnakeHead(){
    return head;
};

void snake::collisonHappened(food * theFood){

    theFood->setPosAgain();

};

QGraphicsRectItem * snake::getSnakeBodyDot(int index){
    return snakeBodies[index];
};

int snake::getNumberOfBodyDots(){
    return snakeBodies.size();
};

void snake::checkForGameOver(int index){
        if (head->x()==snakeBodies[index]->x()&&
                head->y()==snakeBodies[index]->y())
            lost();

};

void snake::lost(){

    for (int i=snakeBodies.size()-1;i>=0;i--){
        scene()->removeItem(snakeBodies[i]);
    }

    qDebug()<<"Game Over";

    //if the next comment is activated to be a programing line , it will crash the program if user loses
    //delete []snakeBody;
};
