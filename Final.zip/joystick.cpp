#include "joystick.h"
#include <QDebug>
joystick::joystick()
{

    SDL_Init(SDL_INIT_JOYSTICK);
    js=SDL_JoystickOpen(0);
    timer=new QTimer(this);
    timer->setInterval(3000);
    timer->start();
    connect(timer,SIGNAL(timeout()),this,SLOT(print()));

};


void joystick::print(){
 //   qDebug()<<SDL_JOYSTICK_AXIS_MAX;

};
