#include "food.h"

food::food(QGraphicsScene * scene)
{
    foodPiece=new QGraphicsRectItem;
    foodPiece->setRect(0,0,40,40);
    QBrush bru;
    bru.setColor(Qt::green);
    bru.setStyle(Qt::SolidPattern);
    foodPiece->setBrush(bru);
    foodPiece->show();
    scene->addItem(foodPiece);

}

void food::setPosAgain(){
    foodPiece->setX(rand()%960);
    foodPiece->setY(rand()%760);
};

QGraphicsRectItem *food::getFoodPiece(){
    return foodPiece;
};
