#ifndef FOOD_H
#define FOOD_H
#include <QGraphicsRectItem>
#include <QBrush>
#include <QGraphicsScene>
class food: public QGraphicsRectItem
{
public:
    food(QGraphicsScene * scene);
    void setPosAgain();
    QGraphicsRectItem *getFoodPiece();
private:
    QGraphicsRectItem * foodPiece;
};

#endif // FOOD_H
