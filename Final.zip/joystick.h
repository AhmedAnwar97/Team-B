#ifndef JOYSTICK_H
#define JOYSTICK_H
#include <SDL.h>
#include <SDL_joystick.h>
#include <QTimer>
#include <QWidget>

class joystick : public QWidget
{
    Q_OBJECT
public:
    joystick();
public slots:
    void print();
private:
    QTimer *timer;
    SDL_Joystick * js;
};

#endif // JOYSTICK_H
