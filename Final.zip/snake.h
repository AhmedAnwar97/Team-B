#ifndef SNAKE_H
#define SNAKE_H
#include <QGraphicsRectItem>
#include <QBrush>
#include <QGraphicsScene>
#include <QDebug>
#include <QPointF>
#include <QObject>
#include <food.h>


class snake: public QGraphicsRectItem , public QObject
{
public:
    snake();
    ~snake();
    void move(int destination);
    void elongate();
    QGraphicsRectItem * getSnakeHead();
    QGraphicsRectItem * getSnakeBodyDot(int index);
    int getNumberOfBodyDots();
    void collisonHappened(food * theFood);
    void checkForGameOver(int index);
    void lost();
private:
    QList<QGraphicsRectItem*> snakeBodies;
    QPointF hori;
    QPointF vert;
    QGraphicsRectItem *head;
    QGraphicsRectItem *tail;
    QGraphicsRectItem *tempo;

};

#endif // SNAKE_H
