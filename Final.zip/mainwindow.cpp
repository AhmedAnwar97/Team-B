#include "mainwindow.h"
#include "ui_mainwindow.h"
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    screen=new QGraphicsView(this);
    scene=new QGraphicsScene(screen);
    screen->setGeometry(0,0,1000,800);
    screen->setFixedSize(1000,800);
    scene->setSceneRect(0,0,1000,800);
    scene->setBackgroundBrush(Qt::black);
    screen->setScene(scene);
    screen->show();
    ourCobra=new snake();
    scene->addItem(ourCobra);
  //
//    hunter=new snake();
//    scene->addItem(hunter);
  //
    itsFood=new food(scene);
    scene->addItem(itsFood);
    setFocus();
    QTimer *timer1;
    QTimer *timer2;
    timer2=new QTimer(this);
    timer2->setInterval(10);
    timer2->start();
    timer1=new QTimer(this);
    timer1->setInterval(300);
    timer1->start();
    connect(timer2,SIGNAL(timeout()),this,SLOT(moveByJoystick()));
    connect(timer1,SIGNAL(timeout()),this,SLOT(moverFn()));
//    js=new joystick();
//    js=SDL_JoystickOpen(0);
//    qDebug()<<"number of axes is "<<SDL_JoystickNumAxes(js);

//    qDebug()<<"Num of button is "<<SDL_JoystickNumButtons;
//    while (SDL_PollEvent(&event)){
//        if(event.type==SDL_JOYAXISMOTION){
//            moveByJoystick();
//        }
//    }
//    qDebug()<<"Connected joysticks: "<<SDL_NumJoysticks();
//        SDL_Init(SDL_INIT_JOYSTICK);
//        SDL_JoystickEventState(SDL_ENABLE);
//        js=SDL_JoystickOpen(0);


//    while(SDL_PollEvent(&event))
//        {
//            switch(event.type)
//            {
//                case SDL_KEYDOWN:
//                qDebug()<<"SLD_KEYDOWN";
//                break;

//                case SDL_QUIT:
//                qDebug()<<"SLD_QUIT";
//                break;
//           case SDL_JOYAXISMOTION:
//                qDebug()<<"SDL JOYAXIXMOTION";
//            case SDL_JOYAXISMOTION:  /* Handle Joystick Motion */
//                if ( ( event.jaxis.value < -3200 ) || (event.jaxis.value > 3200 ) )
//                {
//                  destination=270;
//                }
//                break;
//            }
//        }
/*
    the following is all a socket trial
*/
    }



void MainWindow::moveByJoystick(){
    //if(SDL_JoyAxisEvent())
    SDL_Init(SDL_INIT_JOYSTICK);
    SDL_JoystickEventState(SDL_ENABLE);
    js=SDL_JoystickOpen(0);

                              // 0 is the X axis , 1 is the Y axis , the function returns an int
                              // ranging from -32768 to 32767
    int x_move,y_move;
    while(SDL_PollEvent(&event)){
//            qDebug()<<"Connected joysticks: "<<SDL_NumJoysticks();
            if (event.type==SDL_JOYAXISMOTION)
            {
                if(abs(event.jaxis.value)>15000){
//                    qDebug()<<"motion detected";
                if (event.jaxis.axis==0){
                    x_move=event.jaxis.value;
//                    qDebug()<<"X is "<<x_move;
                    if (x_move>15000){
                        if (destination!=180)
                            destination=0;
                    }
                    else if(x_move<-17000){
                        if (destination!=0)
                            destination=180;
                    }
                }
                else if (event.jaxis.axis==1){
                    y_move=event.jaxis.value;
//                    qDebug()<<"Y is "<<y_move;
                    if (y_move>15000){
                        if (destination!=90)
                            destination=270;
                    }
                    else if(y_move < -17000){
                        if (destination!=270)
                            destination=90;
                    }
                }
                }
                break;
            }
    }
//    moverFn();
}



MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::keyPressEvent(QKeyEvent *event){


    if(event->key()== Qt::Key_Up){
    if(destination!=270){
        destination=90;

    }
    }

    else if(event->key()== Qt::Key_Down){
        if(destination!=90){
            destination=270;

        }
        }

    else if(event->key()== Qt::Key_Right){
        if(destination!=180){
            destination=0;

        }
        }
    else if(event->key()== Qt::Key_Left){
        if(destination!=0){
            destination=180;

        }
        }
/*
    else if(event->key()== Qt::Key_W){
    if(desti2!=270){
        desti2=90;

    }
    }

    else if(event->key()== Qt::Key_S){
        if(desti2!=90){
            desti2=270;

        }
        }

    else if(event->key()== Qt::Key_D){
        if(desti2!=180){
            desti2=0;

        }
        }
    else if(event->key()== Qt::Key_A){
        if(desti2!=0){
            desti2=180;

        }
        };

*/

}

void MainWindow::moverFn(){
    ourCobra->move(destination);
    if(ourCobra->getSnakeHead()->collidesWithItem(itsFood->getFoodPiece()))
    {
        itsFood->setPosAgain();
//        qDebug()<<"ELOngation !";
           ourCobra->elongate();
    }
 //   qDebug()<<ourCobra->getNumberOfBodyDots();
    for (int i=0;i<ourCobra->getNumberOfBodyDots();i++){
        if ((ourCobra->getSnakeHead()->collidesWithItem(ourCobra->getSnakeBodyDot(i)))&&
                ourCobra->getSnakeHead()!=ourCobra->getSnakeBodyDot(i)
                ){
            ourCobra->checkForGameOver(i);
        }
    }
/*
    hunter->move(desti2);
    if(hunter->getSnakeHead()->collidesWithItem(itsFood->getFoodPiece()))
    {
        itsFood->setPosAgain();
        qDebug()<<"ELOngation !";
           hunter->elongate();
    }
    qDebug()<<hunter->getNumberOfBodyDots();
    for (int i=3;i<hunter->getNumberOfBodyDots();i++){
        if (hunter->getSnakeHead()->collidesWithItem(hunter->getSnakeBodyDot(i))&&
            hunter->getSnakeHead()!=hunter->getSnakeBodyDot(i)){
            hunter->checkForGameOver(i);

        }
    }
*/
};
/*
void MainWindow::moveByServer(QString order){
    if (order.compare("UP")==0){
        if (destination !=270)
        destination=90;
    }
    else if (order.compare("DOWN")==0){
        if (destination !=90)
        destination=270;
    }
    else if (order.compare("RIGHT")==0){
        if (destination !=180)
        destination=0;
    }


    else if (order.compare("LEFT")==0){
        if (destination !=0)
        destination=180;
    }
    else if (order.compare("W")==0){
        if (desti2 !=270)
        desti2=90;
    }
    else if (order.compare("S")==0){
        if (desti2 !=90)
        desti2=270;
    }
    else if (order.compare("A")==0){
        if (desti2 !=180)
        desti2=0;
    }
    else if (order.compare("D")==0){
        if (desti2 !=0)
        desti2=180;
    }
};
*/



/*
copied from internet and may help later :
"
I found a weird behaviour in SDL2:

If no events are put into the queue, try adding the following before the SDL_Init call:

SDL_SetHint(SDL_HINT_JOYSTICK_ALLOW_BACKGROUND_EVENTS,"1");
"


*/
