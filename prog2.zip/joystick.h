#ifndef JOYSTICK_H
#define JOYSTICK_H
#include <SDL2/SDL.h>
#include <SDL2/SDL_joystick.h>
#include <QTimer>
#include <QDebug>

class joystick : public QObject
{
    Q_OBJECT


public:
    joystick();
    void ProcImgSend();
    void pist1Strike();
    void pist2Strike();
    void pist1Return();
    void pist2Return();

signals:
    char *getMapped();


public slots:
    void JSLoop();
    void print();
    void JSDataReady();

private:
    SDL_Joystick * js;
    SDL_Event * event;
    int minX=100,maxX=-100,minY=100,maxY=-100,minZ=100,maxZ=-100,maxR=-100,minR=100;
    int map(int value);
    QTimer * timerJS;
    int x=0,y=0,z=0,r=0;

};

#endif // JOYSTICK_H
