#include "tcpsocket.h"

tcpsocket::tcpsocket(QObject *parent, quint16 port)
{
    sock=new QTcpSocket(parent);
    sock->connectToHost("127.0.0.1",port);

    connect(sock,SIGNAL(connected()),this,SLOT(connected()));
//    connect(sock,SIGNAL(()),this,SLOT(connected()));
    connect(sock,SIGNAL(disconnected()),this,SLOT(disconnected()));
    connect(sock,SIGNAL(readyRead()),this,SLOT(readyRread()));
//    connect(sock,SIGNAL(bytesWritten(qint64))),this,SLOT(bytesWritten(qint64));
    if (!sock->waitForConnected(1000))
        qDebug()<<"Error : "<<sock->error();
    else {
        qDebug()<<"Connected successfully. ";
    }
    message=NULL;
}

void tcpsocket::sendOrder()
{
    sock->write(message,elements);
    sock->waitForBytesWritten(40);
}


void tcpsocket::setMessage(char *msg)
{
    elements= strlen(msg);
    message=msg;
    qDebug()<<"Length of message is "<<elements;

}


void tcpsocket::connected(){

    qDebug()<<"connection detected";
    setMessage("Ready to send data");
    sendOrder();

}


void tcpsocket::disconnected(){
//    QHostAddress sender;
//    qDebug()<<"Client"<<sender.toString();

}


void tcpsocket::bytesWritten(qint64 bytes){
    qDebug()<<bytes;

}


void tcpsocket::readyRread(){


}


void tcpsocket::newConnection(){



}
