#ifndef GSTREAM_H
#define GSTREAM_H
#include <QVBoxLayout>

#include <glib.h>
#include <gst/gst.h>
#include <gst/video/videooverlay.h>
#include <QApplication>
#include <QTimer>
#include <QWidget>



class gstream
{
public:
    gstream(QWidget * parent);
    int action(QWidget * renderingWindow);
    QWidget * getStream();
    QWidget * window;
    void setRenderingWindow(QWidget * window);
private:
    GstElement *pipeline;
    GstElement * sink;
    QVBoxLayout * verLay;



};

#endif // GSTREAM_H
